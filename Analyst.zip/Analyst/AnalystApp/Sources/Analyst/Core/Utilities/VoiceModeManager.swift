import Foundation
import Speech
import AVFoundation

/// Manages voice mode for hands-free conversation
@MainActor
class VoiceModeManager: NSObject, ObservableObject {
    
    // MARK: - Singleton
    
    static let shared = VoiceModeManager()
    
    // MARK: - Published Properties
    
    @Published var isVoiceModeEnabled: Bool = false {
        didSet {
            UserDefaults.standard.set(isVoiceModeEnabled, forKey: "voiceModeEnabled")
            if !isVoiceModeEnabled {
                stopVoiceMode()
            }
        }
    }
    
    @Published var isListening: Bool = false
    @Published var isSpeaking: Bool = false
    @Published var currentTranscript: String = ""
    @Published var lastAIResponse: String = ""
    @Published var voiceModeState: VoiceModeState = .idle
    
    // MARK: - Settings
    
    @Published var speechRate: Float = 0.5 {
        didSet { UserDefaults.standard.set(speechRate, forKey: "voiceSpeechRate") }
    }
    
    @Published var speechPitch: Float = 1.0 {
        didSet { UserDefaults.standard.set(speechPitch, forKey: "voiceSpeechPitch") }
    }
    
    @Published var autoDetectSilence: Bool = true {
        didSet { UserDefaults.standard.set(autoDetectSilence, forKey: "voiceAutoDetectSilence") }
    }
    
    @Published var silenceThreshold: Double = 2.0 {
        didSet { UserDefaults.standard.set(silenceThreshold, forKey: "voiceSilenceThreshold") }
    }
    
    @Published var speakResponses: Bool = true {
        didSet { UserDefaults.standard.set(speakResponses, forKey: "voiceSpeakResponses") }
    }
    
    // MARK: - Private Properties
    
    private var speechRecognizer: SFSpeechRecognizer?
    private var audioEngine: AVAudioEngine?
    private var recognitionRequest: SFSpeechAudioBufferRecognitionRequest?
    private var recognitionTask: SFSpeechRecognitionTask?
    private var synthesizer: AVSpeechSynthesizer?
    
    private var silenceTimer: Timer?
    private var lastSpeechTime: Date?
    private var accumulatedText: String = ""
    
    // MARK: - Types
    
    enum VoiceModeState {
        case idle
        case listening
        case processing
        case speaking
        
        var statusText: String {
            switch self {
            case .idle: return "Tap to speak"
            case .listening: return "Listening..."
            case .processing: return "Thinking..."
            case .speaking: return "Speaking..."
            }
        }
        
        var iconName: String {
            switch self {
            case .idle: return "mic"
            case .listening: return "mic.fill"
            case .processing: return "brain.head.profile"
            case .speaking: return "speaker.wave.3.fill"
            }
        }
    }
    
    // MARK: - Init
    
    private override init() {
        super.init()
        
        // Load saved settings
        isVoiceModeEnabled = UserDefaults.standard.bool(forKey: "voiceModeEnabled")
        speechRate = Float(UserDefaults.standard.double(forKey: "voiceSpeechRate"))
        if speechRate == 0 { speechRate = 0.5 }
        speechPitch = Float(UserDefaults.standard.double(forKey: "voiceSpeechPitch"))
        if speechPitch == 0 { speechPitch = 1.0 }
        autoDetectSilence = UserDefaults.standard.object(forKey: "voiceAutoDetectSilence") as? Bool ?? true
        silenceThreshold = UserDefaults.standard.double(forKey: "voiceSilenceThreshold")
        if silenceThreshold == 0 { silenceThreshold = 2.0 }
        speakResponses = UserDefaults.standard.object(forKey: "voiceSpeakResponses") as? Bool ?? true
        
        // Initialize speech recognizer
        speechRecognizer = SFSpeechRecognizer(locale: Locale(identifier: "en-US"))
        
        // Initialize synthesizer
        synthesizer = AVSpeechSynthesizer()
        synthesizer?.delegate = self
    }
    
    // MARK: - Voice Mode Control
    
    func startVoiceMode() {
        guard isVoiceModeEnabled else { return }
        voiceModeState = .idle
    }
    
    func stopVoiceMode() {
        stopListening()
        stopSpeaking()
        voiceModeState = .idle
        currentTranscript = ""
        lastAIResponse = ""
    }
    
    // MARK: - Listening
    
    func startListening() async -> Bool {
        guard await requestPermissions() else {
            return false
        }
        
        guard let recognizer = speechRecognizer, recognizer.isAvailable else {
            return false
        }
        
        // Configure audio session
        let audioSession = AVAudioSession.sharedInstance()
        do {
            try audioSession.setCategory(.playAndRecord, mode: .default, options: [.duckOthers, .allowBluetooth])
            try audioSession.setActive(true)
        } catch {
            print("❌ Audio session error: \(error)")
            return false
        }
        
        // Setup audio engine
        audioEngine = AVAudioEngine()
        let inputNode = audioEngine!.inputNode
        let recordingFormat = inputNode.outputFormat(forBus: 0)
        
        // Create recognition request
        recognitionRequest = SFSpeechAudioBufferRecognitionRequest()
        recognitionRequest!.shouldReportPartialResults = true
        recognitionRequest!.addsPunctuation = true
        
        // Install tap on input node
        inputNode.installTap(onBus: 0, bufferSize: 1024, format: recordingFormat) { buffer, _ in
            self.recognitionRequest?.append(buffer)
        }
        
        // Start recognition task
        accumulatedText = ""
        recognitionTask = recognizer.recognitionTask(with: recognitionRequest!) { [weak self] result, error in
            Task { @MainActor in
                self?.handleRecognitionResult(result, error: error)
            }
        }
        
        // Start audio engine
        audioEngine?.prepare()
        do {
            try audioEngine?.start()
        } catch {
            print("❌ Audio engine start error: \(error)")
            return false
        }
        
        isListening = true
        voiceModeState = .listening
        HapticManager.shared.mediumImpact()
        
        // Start silence detection
        if autoDetectSilence {
            startSilenceDetection()
        }
        
        return true
    }
    
    func stopListening() {
        audioEngine?.stop()
        audioEngine?.inputNode.removeTap(onBus: 0)
        recognitionTask?.cancel()
        recognitionTask = nil
        recognitionRequest = nil
        silenceTimer?.invalidate()
        silenceTimer = nil
        
        isListening = false
        
        // Deactivate audio session
        try? AVAudioSession.sharedInstance().setActive(false)
    }
    
    private func handleRecognitionResult(_ result: SFSpeechRecognitionResult?, error: Error?) {
        guard let result = result else {
            if let error = error {
                print("❌ Recognition error: \(error)")
            }
            return
        }
        
        currentTranscript = result.bestTranscription.formattedString
        
        // Update last speech time for silence detection
        if !currentTranscript.isEmpty {
            lastSpeechTime = Date()
        }
        
        // If final, process the text
        if result.isFinal {
            accumulatedText = currentTranscript
        }
    }
    
    // MARK: - Silence Detection
    
    private func startSilenceDetection() {
        lastSpeechTime = Date()
        silenceTimer = Timer.scheduledTimer(withTimeInterval: 0.5, repeats: true) { [weak self] _ in
            Task { @MainActor in
                self?.checkForSilence()
            }
        }
    }
    
    private func checkForSilence() {
        guard let lastSpeech = lastSpeechTime else { return }
        
        let elapsed = Date().timeIntervalSince(lastSpeech)
        if elapsed >= silenceThreshold && !currentTranscript.isEmpty {
            // User has stopped speaking
            finishListeningAndProcess()
        }
    }
    
    func finishListeningAndProcess() {
        guard !currentTranscript.isEmpty else { return }
        
        stopListening()
        voiceModeState = .processing
        HapticManager.shared.lightImpact()
    }
    
    // MARK: - Speaking (Text-to-Speech)
    
    func speak(_ text: String) {
        guard !text.isEmpty else { return }
        
        // Clean up text for more natural speech
        let cleanText = prepareTextForSpeech(text)
        
        let utterance = AVSpeechUtterance(string: cleanText)
        
        // Use a more natural speech rate (slightly slower than default)
        // Average human speech is around 150 WPM, default TTS is faster
        let naturalRate: Float = 0.45 // 0.0 to 1.0 scale, 0.5 is default
        utterance.rate = naturalRate + (speechRate - 0.5) * 0.3 // Allow small adjustments
        
        // Natural pitch variation (slightly lower for a more warm, natural sound)
        utterance.pitchMultiplier = 0.95 + (speechPitch - 1.0) * 0.2
        
        // Add slight variation for more natural sound
        utterance.preUtteranceDelay = 0.1 // Small pause before speaking
        utterance.postUtteranceDelay = 0.2 // Small pause after speaking
        
        // Try to use the best available English voice
        utterance.voice = getBestAvailableVoice()
        
        // Configure audio session for high-quality playback
        do {
            try AVAudioSession.sharedInstance().setCategory(
                .playback,
                mode: .voicePrompt,
                options: [.allowBluetooth, .allowBluetoothA2DP]
            )
            try AVAudioSession.sharedInstance().setActive(true)
        } catch {
            print("❌ Audio session config error: \(error)")
        }
        
        isSpeaking = true
        voiceModeState = .speaking
        lastAIResponse = text
        
        synthesizer?.speak(utterance)
    }
    
    /// Prepare text for more natural speech by cleaning up formatting
    private func prepareTextForSpeech(_ text: String) -> String {
        var cleanText = text
        
        // Remove markdown formatting
        cleanText = cleanText.replacingOccurrences(of: "\\*\\*(.+?)\\*\\*", with: "$1", options: .regularExpression)
        cleanText = cleanText.replacingOccurrences(of: "\\*(.+?)\\*", with: "$1", options: .regularExpression)
        cleanText = cleanText.replacingOccurrences(of: "__(.+?)__", with: "$1", options: .regularExpression)
        cleanText = cleanText.replacingOccurrences(of: "`(.+?)`", with: "$1", options: .regularExpression)
        
        // Handle code blocks - just say "code block" instead of reading them
        cleanText = cleanText.replacingOccurrences(of: "```[\\s\\S]*?```", with: " code block. ", options: .regularExpression)
        
        // Replace common abbreviations with their spoken forms
        cleanText = cleanText.replacingOccurrences(of: "\\bAFL\\b", with: "A F L")
        cleanText = cleanText.replacingOccurrences(of: "\\bAPI\\b", with: "A P I")
        cleanText = cleanText.replacingOccurrences(of: "\\bURL\\b", with: "U R L")
        cleanText = cleanText.replacingOccurrences(of: "\\bJSON\\b", with: "JSON")
        cleanText = cleanText.replacingOccurrences(of: "\\bID\\b", with: "I D")
        cleanText = cleanText.replacingOccurrences(of: "\\bCEO\\b", with: "C E O")
        cleanText = cleanText.replacingOccurrences(of: "\\bCFO\\b", with: "C F O")
        cleanText = cleanText.replacingOccurrences(of: "\\bUS\\b", with: "U S")
        cleanText = cleanText.replacingOccurrences(of: "\\bUSA\\b", with: "U S A")
        cleanText = cleanText.replacingOccurrences(of: "\\bETF\\b", with: "E T F")
        cleanText = cleanText.replacingOccurrences(of: "\\bIPO\\b", with: "I P O")
        cleanText = cleanText.replacingOccurrences(of: "\\bROI\\b", with: "R O I")
        cleanText = cleanText.replacingOccurrences(of: "\\bYOY\\b", with: "year over year")
        cleanText = cleanText.replacingOccurrences(of: "\\bQ1\\b", with: "first quarter")
        cleanText = cleanText.replacingOccurrences(of: "\\bQ2\\b", with: "second quarter")
        cleanText = cleanText.replacingOccurrences(of: "\\bQ3\\b", with: "third quarter")
        cleanText = cleanText.replacingOccurrences(of: "\\bQ4\\b", with: "fourth quarter")
        
        // Handle symbols
        cleanText = cleanText.replacingOccurrences(of: "%", with: " percent")
        cleanText = cleanText.replacingOccurrences(of: "&", with: " and ")
        cleanText = cleanText.replacingOccurrences(of: "@", with: " at ")
        cleanText = cleanText.replacingOccurrences(of: "#", with: " ")
        cleanText = cleanText.replacingOccurrences(of: "$", with: " dollars ")
        
        // Add natural pauses
        cleanText = cleanText.replacingOccurrences(of: "\\.\\.\\.", with: ". ") // Ellipsis
        cleanText = cleanText.replacingOccurrences(of: ":", with: ", ") // Colons become pauses
        cleanText = cleanText.replacingOccurrences(of: ";", with: ", ") // Semicolons become pauses
        cleanText = cleanText.replacingOccurrences(of: "—", with: ", ") // Em dashes become pauses
        cleanText = cleanText.replacingOccurrences(of: "–", with: ", ") // En dashes become pauses
        
        // Clean up extra whitespace
        cleanText = cleanText.replacingOccurrences(of: "\\s+", with: " ", options: .regularExpression)
        cleanText = cleanText.trimmingCharacters(in: .whitespacesAndNewlines)
        
        return cleanText
    }
    
    /// Get the best available voice for hyper-realistic natural speech
    private func getBestAvailableVoice() -> AVSpeechSynthesisVoice? {
        let voices = AVSpeechSynthesisVoice.speechVoices()
        let usEnglishVoices = voices.filter { $0.language == "en-US" }
        let allEnglishVoices = voices.filter { $0.language.hasPrefix("en") }
        
        // 1. First try premium quality US English voices (most natural)
        if let premium = usEnglishVoices.first(where: { $0.quality == .premium }) {
            print("🎙️ Using premium voice: \(premium.name)")
            return premium
        }
        
        // 2. Try enhanced quality US English voices
        if let enhanced = usEnglishVoices.first(where: { $0.quality == .enhanced }) {
            print("🎙️ Using enhanced voice: \(enhanced.name)")
            return enhanced
        }
        
        // 3. Try premium quality any English
        if let premium = allEnglishVoices.first(where: { $0.quality == .premium }) {
            print("🎙️ Using premium English voice: \(premium.name)")
            return premium
        }
        
        // 4. Try enhanced quality any English
        if let enhanced = allEnglishVoices.first(where: { $0.quality == .enhanced }) {
            print("🎙️ Using enhanced English voice: \(enhanced.name)")
            return enhanced
        }
        
        // 5. Try specific known-good voice identifiers
        let knownVoices = [
            "com.apple.voice.premium.en-US.Zoe",
            "com.apple.voice.premium.en-US.Samantha",
            "com.apple.voice.premium.en-US.Aaron",
            "com.apple.voice.enhanced.en-US.Samantha",
            "com.apple.voice.enhanced.en-US.Aaron",
            "com.apple.voice.enhanced.en-US.Zoe",
            "com.apple.voice.compact.en-US.Samantha",
            "com.apple.voice.compact.en-US.Aaron"
        ]
        
        for voiceId in knownVoices {
            if let voice = AVSpeechSynthesisVoice(identifier: voiceId) {
                print("🎙️ Using known voice: \(voice.name)")
                return voice
            }
        }
        
        // 6. Fall back to default US English
        print("🎙️ Using default en-US voice")
        return AVSpeechSynthesisVoice(language: "en-US")
    }
    
    func stopSpeaking() {
        synthesizer?.stopSpeaking(at: .immediate)
        isSpeaking = false
    }
    
    // MARK: - Permissions
    
    private func requestPermissions() async -> Bool {
        // Check speech recognition permission
        let speechAuth = SFSpeechRecognizer.authorizationStatus()
        if speechAuth == .notDetermined {
            let granted = await withCheckedContinuation { continuation in
                SFSpeechRecognizer.requestAuthorization { status in
                    continuation.resume(returning: status == .authorized)
                }
            }
            if !granted { return false }
        } else if speechAuth != .authorized {
            return false
        }
        
        // Check microphone permission
        let micAuth = AVAudioApplication.shared.recordPermission
        if micAuth == .undetermined {
            let granted = await AVAudioApplication.requestRecordPermission()
            return granted
        }
        
        return micAuth == .granted
    }
}

// MARK: - AVSpeechSynthesizerDelegate

extension VoiceModeManager: AVSpeechSynthesizerDelegate {
    nonisolated func speechSynthesizer(_ synthesizer: AVSpeechSynthesizer, didFinish utterance: AVSpeechUtterance) {
        Task { @MainActor in
            self.isSpeaking = false
            self.voiceModeState = .idle
            HapticManager.shared.lightImpact()
        }
    }
    
    nonisolated func speechSynthesizer(_ synthesizer: AVSpeechSynthesizer, didCancel utterance: AVSpeechUtterance) {
        Task { @MainActor in
            self.isSpeaking = false
            self.voiceModeState = .idle
        }
    }
}