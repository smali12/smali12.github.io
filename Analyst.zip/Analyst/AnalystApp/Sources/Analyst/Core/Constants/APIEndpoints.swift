import Foundation

enum APIEndpoints {
    // MARK: - Base URL
    
    // Always use production backend
    static let baseURL = "https://potomac-analyst-workbench-production.up.railway.app"
    
    // MARK: - Auth Endpoints
    
    enum Auth {
        static let register = "/auth/register"
        static let login = "/auth/login"
        static let logout = "/auth/logout"
        static let me = "/auth/me"
        static let refresh = "/auth/refresh-token"
        static let changePassword = "/auth/change-password"
        static let forgotPassword = "/auth/forgot-password"
        static let resetPassword = "/auth/reset-password"
    }
    
    // MARK: - Chat Endpoints
    
    enum Chat {
        static let conversations = "/chat/conversations"
        static func conversation(_ id: String) -> String { "/chat/conversations/\(id)" }
        static func messages(_ conversationId: String) -> String { "/chat/conversations/\(conversationId)/messages" }
        static let sendMessage = "/chat/message"
        static let stream = "/chat/stream"
        static let streamV6 = "/chat/v6"
        static func upload(_ conversationId: String) -> String { "/chat/conversations/\(conversationId)/upload" }
        static let tts = "/chat/tts"
    }
    
    // MARK: - AFL Endpoints
    
    enum AFL {
        static let generate = "/afl/generate"
        static let optimize = "/afl/optimize"
        static let debug = "/afl/debug"
        static let explain = "/afl/explain"
        static let validate = "/afl/validate"
        static let codes = "/afl/codes"
        static func code(_ id: String) -> String { "/afl/codes/\(id)" }
        static let history = "/afl/history"
        static func historyItem(_ id: String) -> String { "/afl/history/\(id)" }
        static let upload = "/afl/upload"
        static let presets = "/afl/settings/presets"
        static func preset(_ id: String) -> String { "/afl/settings/presets/\(id)" }
    }
    
    // MARK: - Brain/Knowledge Base Endpoints
    
    enum Brain {
        static let upload = "/brain/upload"
        static let uploadBatch = "/brain/upload-batch"
        static let uploadText = "/brain/upload-text"
        static let search = "/brain/search"
        static let documents = "/brain/documents"
        static func document(_ id: String) -> String { "/brain/documents/\(id)" }
        static let stats = "/brain/stats"
    }
    
    // MARK: - Backtest Endpoints
    
    enum Backtest {
        static let upload = "/backtest/upload"
        static func backtest(_ id: String) -> String { "/backtest/\(id)" }
        static func strategy(_ id: String) -> String { "/backtest/strategy/\(id)" }
    }
    
    // MARK: - Researcher Endpoints
    
    enum Researcher {
        static func company(_ symbol: String) -> String { "/api/researcher/company/\(symbol)" }
        static func news(_ symbol: String) -> String { "/api/researcher/news/\(symbol)" }
        static let strategyAnalysis = "/api/researcher/strategy-analysis"
        static let macroContext = "/api/researcher/macro-context"
        static let search = "/api/researcher/search"
        static let trending = "/api/researcher/trending"
    }
    
    // MARK: - Presentation Endpoints
    
    enum Presentation {
        static let generate = "/content/slides/generate"
        static func jobStatus(_ jobId: String) -> String { "/content/jobs/\(jobId)" }
        static func download(_ id: String) -> String { "/chat/presentation/\(id)" }
    }
}
