import SwiftUI

struct CustomTabBar: View {
    @Environment(TabViewModel.self) private var tabVM

    var body: some View {
        HStack(spacing: 0) {
            ForEach(TabViewModel.Tab.allCases, id: \.self) { tab in
                TabBarButton(
                    tab: tab,
                    isSelected: tabVM.selectedTab == tab
                ) {
                    tabVM.select(tab)
                }
            }
        }
        .padding(.horizontal, 8)
        .padding(.top, 10)
        .padding(.bottom, 28) // accounts for home indicator
        .background(
            Rectangle()
                .fill(.ultraThinMaterial)
                .overlay(
                    Rectangle()
                        .fill(Color.white.opacity(0.04))
                )
                .overlay(
                    Rectangle()
                        .fill(Color.white.opacity(0.08))
                        .frame(height: 0.5),
                    alignment: .top
                )
                .ignoresSafeArea()
        )
    }
}

// MARK: - Tab Bar Button

private struct TabBarButton: View {
    let tab: TabViewModel.Tab
    let isSelected: Bool
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            VStack(spacing: 4) {
                Image(systemName: isSelected ? tab.selectedIcon : tab.icon)
                    .font(.system(size: 20, weight: isSelected ? .semibold : .regular))
                    .foregroundColor(isSelected ? .potomacYellow : .white.opacity(0.4))
                    .scaleEffect(isSelected ? 1.05 : 1.0)
                    .animation(.spring(response: 0.3, dampingFraction: 0.7), value: isSelected)

                Text(tab.rawValue)
                    .font(.quicksandSemiBold(10))
                    .foregroundColor(isSelected ? .potomacYellow : .white.opacity(0.35))
            }
            .frame(maxWidth: .infinity)
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
    }
}

#Preview {
    ZStack(alignment: .bottom) {
        Color(hex: "0A0A0A").ignoresSafeArea()
        CustomTabBar()
    }
    .environment(TabViewModel())
}