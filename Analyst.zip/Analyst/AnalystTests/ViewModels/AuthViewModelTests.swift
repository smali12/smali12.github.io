//
//  AuthViewModelTests.swift
//  AnalystTests
//
//  Phase 8: Unit tests for AuthViewModel
//

import XCTest
@testable import Analyst

final class AuthViewModelTests: XCTestCase {
    
    var sut: AuthViewModel!
    var mockKeychain: MockKeychainManager!
    
    override func setUp() {
        super.setUp()
        mockKeychain = MockKeychainManager()
        sut = AuthViewModel()
    }
    
    override func tearDown() {
        sut = nil
        mockKeychain = nil
        super.tearDown()
    }
    
    // MARK: - Initial State Tests
    
    func testInitialState_notAuthenticated() {
        XCTAssertFalse(sut.isAuthenticated)
        XCTAssertNil(sut.user)
        XCTAssertFalse(sut.isLoading)
    }
    
    // MARK: - Logout Tests
    
    func testLogout_clearsUser() async {
        // Given
        sut.user = User(id: "test", email: "test@test.com", name: "Test User")
        sut.isAuthenticated = true
        
        // When
        await sut.logout()
        
        // Then
        XCTAssertFalse(sut.isAuthenticated)
        XCTAssertNil(sut.user)
    }
    
    // MARK: - User Initials Tests
    
    func testUserInitials_fromName() {
        // Given
        let user = User(id: "1", email: "test@test.com", name: "John Doe")
        
        // Then
        XCTAssertEqual(user.initials, "JD")
    }
    
    func testUserInitials_fromEmail() {
        // Given
        let user = User(id: "1", email: "testuser@test.com", name: nil)
        
        // Then
        XCTAssertEqual(user.initials, "T")
    }
    
    // MARK: - Display Name Tests
    
    func testDisplayName_usesName() {
        // Given
        let user = User(id: "1", email: "test@test.com", name: "John Doe", nickname: nil)
        
        // Then
        XCTAssertEqual(user.displayName, "John Doe")
    }
    
    func testDisplayName_usesNickname() {
        // Given
        let user = User(id: "1", email: "test@test.com", name: "John Doe", nickname: "Johnny")
        
        // Then
        XCTAssertEqual(user.displayName, "Johnny")
    }
}

// MARK: - Mock Keychain Manager

class MockKeychainManager {
    var storedTokens: [String: String] = [:]
    
    func set(_ value: String, forKey key: String) throws {
        storedTokens[key] = value
    }
    
    func get(_ key: String) -> String? {
        return storedTokens[key]
    }
    
    func delete(_ key: String) {
        storedTokens.removeValue(forKey: key)
    }
    
    func deleteAll() {
        storedTokens.removeAll()
    }
}