//
//  ChatViewModelTests.swift
//  AnalystTests
//
//  Phase 8: Unit tests for ChatViewModel
//

import XCTest
@testable import Analyst

final class ChatViewModelTests: XCTestCase {
    
    var sut: ChatViewModel!
    var mockAPIClient: MockAPIClient!
    var mockSSEClient: MockSSEClient!
    
    override func setUp() {
        super.setUp()
        mockAPIClient = MockAPIClient()
        mockSSEClient = MockSSEClient()
        sut = ChatViewModel(apiClient: mockAPIClient, sseClient: mockSSEClient, hapticManager: HapticManager.shared)
    }
    
    override func tearDown() {
        sut = nil
        mockAPIClient = nil
        mockSSEClient = nil
        super.tearDown()
    }
    
    // MARK: - Load Conversations Tests
    
    func testLoadConversations_success() async {
        // Given
        let expectedConversations = [
            Conversation(id: "1", title: "Test Chat 1", createdAt: Date()),
            Conversation(id: "2", title: "Test Chat 2", createdAt: Date())
        ]
        mockAPIClient.conversationsToReturn = expectedConversations
        
        // When
        await sut.loadConversations()
        
        // Then
        XCTAssertEqual(sut.conversations.count, 2)
        XCTAssertEqual(sut.conversations.first?.title, "Test Chat 1")
        XCTAssertFalse(sut.isLoadingConversations)
    }
    
    func testLoadConversations_empty() async {
        // Given
        mockAPIClient.conversationsToReturn = []
        
        // When
        await sut.loadConversations()
        
        // Then
        XCTAssertTrue(sut.conversations.isEmpty)
    }
    
    // MARK: - Create Conversation Tests
    
    func testCreateNewConversation_success() async {
        // Given
        let newConversation = Conversation(id: "new-1", title: "New Chat", createdAt: Date())
        mockAPIClient.conversationToReturn = newConversation
        
        // When
        await sut.createNewConversation()
        
        // Then
        XCTAssertNotNil(sut.currentConversation)
        XCTAssertEqual(sut.currentConversation?.id, "new-1")
        XCTAssertEqual(sut.conversations.first?.id, "new-1")
    }
    
    // MARK: - Send Message Tests
    
    func testSendMessage_addsUserMessage() async {
        // Given
        let conversation = Conversation(id: "conv-1", title: "Test", createdAt: Date())
        await sut.selectConversation(conversation)
        
        // When
        await sut.sendMessage("Hello, world!")
        
        // Then
        XCTAssertEqual(sut.messages.count, 1)
        XCTAssertEqual(sut.messages.first?.content, "Hello, world!")
        XCTAssertEqual(sut.messages.first?.role, .user)
    }
    
    func testSendMessage_emptyText_doesNotSend() async {
        // Given
        let conversation = Conversation(id: "conv-1", title: "Test", createdAt: Date())
        await sut.selectConversation(conversation)
        
        // When
        await sut.sendMessage("   ")
        
        // Then
        XCTAssertTrue(sut.messages.isEmpty)
    }
    
    // MARK: - Stop Streaming Tests
    
    func testStopStreaming_cancelsAndResets() async {
        // Given
        sut.isStreaming = true
        
        // When
        sut.stopStreaming()
        
        // Then
        XCTAssertFalse(sut.isStreaming)
        XCTAssertTrue(sut.streamingText.isEmpty)
    }
}

// MARK: - Mock API Client

class MockAPIClient: APIClient {
    var conversationsToReturn: [Conversation] = []
    var conversationToReturn: Conversation?
    var messagesToReturn: [Message] = []
    var shouldThrow = false
    
    override func getConversations() async throws -> [Conversation] {
        if shouldThrow { throw TestError.mockError }
        return conversationsToReturn
    }
    
    override func createConversation(title: String?) async throws -> Conversation {
        if shouldThrow { throw TestError.mockError }
        return conversationToReturn ?? Conversation(id: UUID().uuidString, title: title, createdAt: Date())
    }
    
    override func getMessages(conversationId: String) async throws -> [Message] {
        if shouldThrow { throw TestError.mockError }
        return messagesToReturn
    }
}

// MARK: - Mock SSE Client

class MockSSEClient: SSEClient {
    var eventsToReturn: [StreamEvent] = []
    
    override func streamMessage(conversationId: String, message: String) async -> AsyncThrowingStream<StreamEvent, Error> {
        AsyncThrowingStream { continuation in
            for event in eventsToReturn {
                continuation.yield(event)
            }
            continuation.finish()
        }
    }
}

// MARK: - Test Error

enum TestError: Error {
    case mockError
}